#!/bin/bash -f
# $Id: timediff.sh 8 2018-08-14 09:35:17Z vinays $
startt=$1
endt=$2
diff=$(( endt - startt ))
echo $diff
hours=`echo "$diff/3600" | bc`
mod=`echo "$diff%3600" | bc`
mins=`echo "$mod/60" | bc`
secs=`echo "$mod%60" | bc`

echo "${hours}:${mins}:${secs}"
