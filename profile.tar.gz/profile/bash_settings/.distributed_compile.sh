#!/bin/bash -f
# $Id: .distributed_compile.sh 8 2018-08-14 09:35:17Z vinays $

rm -rf .g++Commands .run_lex.csh
make -nk $* | grep g++ > .g++Commands
make -nk $* | grep -v g++ | grep -v echo > .run_lex.sh

if  [[ -s .run_lex.sh ]] ; then
    source ./.run_lex.sh >& /dev/null
fi


if  [[ -s .g++Commands ]] ; then
    count=`wc -l .g++Commands | awk '{print $1}'`
    divisor=`echo "(($count-1)/40) + 1" | bc`
    numLines=`echo "$count/$divisor + 1" | bc`
    rm -rf xaa xab xac
    split -l $numLines .g++Commands

    for file in xaa xab xac; do
        if  [[ -s $file ]] ; then
	        source $file > /dev/null &
        fi
    done
fi


wait
