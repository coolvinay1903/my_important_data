#!/bin/bash -fv

export PATH=/med/build/gcc/gcc-6.2.0/rhel6/bin/:${PATH}
if [[ ! -z $LD_LIBRARY_PATH ]]  ; then
    export LD_LIBRARY_PATH=/med/build/gcc/gcc-6.2.0/rhel6/lib64/:$LD_LIBRARY_PATH
else
    export LD_LIBRARY_PATH=/med/build/gcc/gcc-6.2.0/rhel6/lib64
fi
