 ###### Acrobat reader 9.4.2 #######

pa=`echo ${PATH} | sed -e 's/\/in\/Acrobat942\/bin//g'`
export PATH=/in/Acrobat942/bin:$pa
