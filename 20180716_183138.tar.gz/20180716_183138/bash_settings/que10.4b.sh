#!/bin/bash
###### Setting up questasim_10.4b ######

###### Setting MGC_HOME and aliases ######

export MGC_HOME=/u/release/10.4b/questasim
export MGC_TMPDIR=/tmp
export MGC_CVE_LOG=1

source ~/bash_settings/mti-include.sh
