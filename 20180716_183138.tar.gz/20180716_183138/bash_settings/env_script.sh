#!/bin/bash

# This script needs to be sourced whenever a new shell is being used to set all the environment variables. licenses etc. to proper values

DOMAIN_NAME=`domainname`
if  [[ $DOMAIN_NAME == "inn.mentorg.com" ]] ; then
    export MED_SITE=Noida
    if [[ -z $VPS_REGRESSIONS ]] ;then
        if [[ -z $VMW_BIN ]] ;then
            export VMW_BIN=gnu.debug
        fi
    fi
else
    export MED_SITE=Meudon
fi

export SYSC_LIB=lib/linux_el30_gnu45/

if [[ ! -z $MED_TBX_HOME ]] ;then
    export TBX_HOME=$MED_TBX_HOME
else
    export TBX_HOME=$VMW_HOME/tbx
fi
export MW_HOME=$TBX_HOME

if  [[  $MED_SITE == "Meudon" ]] ; then
    export SYSTEMC=$VMW_HOME/bin/med_tools/linux/systemc
    if [[ -z $LM_LICENSE_FILE ]] ;then
        export LM_LICENSE_FILE=1717@innnis3.inn.mentorg.com:1718@wv-lic-snpslmd.wv.mentorg.com
    else
        export LM_LICENSE_FILE=1717@innnis3.inn.mentorg.com:1718@wv-lic-snpslmd.wv.mentorg.com:$LM_LICENSE_FILE
    fi

    # Set BEHAVC_REG_HOME
    setBhvc=1
    if [[ ! -z $BEHAVC_REG_HOME ]]  ; then
        if  [[ ! -d "$BEHAVC_REG_HOME" ]] ; then
            echo "BEHAVC_REG_HOME = $BEHAVC_REG_HOME does not exist" >> /dev/stderr
            # exit 1 # ASV: Not sure if we should exit or not
        else
            setBhvc=0
        fi
    fi

    # Will set only if it is not already set  [[ and is a valid setting ]]
    if [[  $setBhvc  ]]; then export BEHAVC_REG_HOME=/home/medqa/SANDBOXES/TBX_REGRESSIONS; fi

    export ROOT_TBX="/misc/vel/tbx/abhattac"

    export HOME_0IN=/med/tools/zero-in/10.4b_1/linux_x86_64 #for tbx 2.5 set this home 0in

    #setenv MGC_HOME /med/tools/QuestaSim/QuestaSim_10.4d/questasim
    export MGC_HOME=/med/tools/QuestaSim/10.5b/questasim
    export ROOT_QUESTA=$MGC_HOME

    export MACHLIST=$TBXREGINFRA/scripts/machlist_meudon
    export TBX_USE_VCSI=1
    export VCS_ARCH_OVERRIDE=linux
    export VCSI_HOME=/usr/soft/VCS/vcs2011.03/
    export VCS_HOME=/usr/soft/VCS/vcs2011.03/
    export PATH=$VCS_HOME/bin/:${PATH}

else
    # NOIDA
    export SYSTEMC=$VMW_HOME/bin/med_tools/linux/systemc
    export LM_LICENSE_FILE_TMP=1717@svr-inn-nis-01:1717@svr-inn-nis-03:1718@wv-lic-snpslmd.wv.mentorg.com:1718@vanginkel.ies.mentorg.com:1717@innnis4.inn.mentorg.com:1717@innnis3.inn.mentorg.com:1718@wv-lic-snpslmd.wv.mentorg.com::1717@wv-lic-03.wv.mentorg.com:1717@vanginkel.ies.mentorg.com:1717@lichoste.wv.mentorg.com:1717@solmaster.wv.mentorg.com:/LICENSES/mgc.innnis1:/LICENSES/mgc.innnis2:1717@inndt262.inn.mentorg.com:27001@svr-inn-nis-01:27000@svr-inn-nis-01
    if [[ ! -z $VPS_REGRESSIONS ]] ;then
        if [[ -z $LM_LICENSE_FILE ]] ;then
            export LM_LICENSE_FILE=""
        fi
        export LM_LICENSE_FILE="$LM_LICENSE_FILE_TMP":$LM_LICENSE_FILE
    else
        export LM_LICENSE_FILE=$LM_LICENSE_FILE_TMP
    fi
    unset LM_LICENSE_FILE_TMP

    # Set BEHAVC_REG_HOME
    if [[ -z $BEHAVC_REG_HOME ]] ; then
        for bhvRegHome in " ~tbxreg/regressions/TBX_REGRESSIONS /home/medqa/SANDBOXES/tbx_regressions/regressions/TBX_REGRESSIONS"; do
            if  [[ -e $bhvRegHome ]] ; then 
                export BEHAVC_REG_HOME=$bhvRegHome
                break
            fi
        done
        unset bhvRegHome
    fi

    export MACHLIST=$TBXREGINFRA/scripts/OS3/machlist_noida
    export ROOT_TBX=/home/tbx

    #source /ENV/que6.6e
    source /home/vinays/bash_settings/que10.4b.sh
    ################ ASV- This should be for Noida only
    export ROOT_QUESTA=$MGC_HOME
    export HOME_0IN=/in/zero-in-v10.3d_4/linux/linux_x86_64
fi

export VELCOMP_TBX_MERGE_REG=1
export OS3_REG_ALLOW_LOWER_QUESTA=1

if [[ -z $DIAMOND_HW ]] ; then
    export TBX_REGRESS=1 # This is for cview only
fi
export DIAMOND=1
export TBX_REGRESSIONS=1
export MTI_VCO_MODE=32
export HOME_RTLREG=$ROOT_TBX/rtlreg
export TIME_CONTROL=1

export PATH=$ROOT_QUESTA/bin/:${PATH}
export PATH=$HOME_0IN/bin/:${PATH}

export PATH=$VMW_HOME/bin:${PATH}
export PATH=$TBX_HOME/bin:${PATH}
export PATH=$TBX_HOME/rtlc/bin:${PATH}

source /home/vinays/bash_settings/set_BRANCH.sh
export BUILD_PLATFORM=linux_el30_gnu53
export VELOCE_BETA_VARIABLE="VeloceUCISXML31618 VeloceTransitionBin1703 VeloceRTLTrigger1802"
if [[ $BRANCH == tbx_3161 || $BRANCH == tbx_1703 ]]; then
    export BUILD_PLATFORM=linux_el30_gnu45
fi
export VERILOG=my_mti
export BEHAVC_COMMON_OPT="-hdl verilog -write_cdfg -allow_4ST -preserve -process_sign -compile_hier_tf"
export BEHAVC_COMMON_OPT="$BEHAVC_COMMON_OPT -allow_bhv_sysvlog"
export DESIGN_OPTIONS="-hdl verilog -write_cdfg -process_sign -allow_4ST -allow_PD -allow_STR -allow_IAD -allow_ZPN -allow_ZPR"
export VERILOG_COMMON_OPT="+define+BEHAVC +define+NO_VCD_DUMP +define+BEHAVC_SIM"
export TIPSIM_COMMON_OPT="-y ./rtlc.out +libext+.v +loadpli1=$BEHAVC_REG_HOME/lib/libmctpli.so:mctsim_bootstrap +define+BEHAVC_SYSTF_TIP -v $VMW_HOME/TIP/tipsim/verilog/tipComodelMacros.v +incdir+$BEHAVC_REG_HOME/lib +define+BEHAVC_EXTERN_CLK +define+BEHAVC_TIPSIM "
export HDL_PLATFORM=mti

export BEHAVC_HOME=$TBX_HOME/rtlc
export RTLC_HOME=$TBX_HOME/rtlc
export MIXED_RTLC_HOME=$TBX_HOME/rtlc
if [[ ! -z $BEHAVC_EXEC ]]  ; then
    export BEHAVC_EXEC=$BEHAVC_EXEC
else
    export BEHAVC_EXEC=$TBX_HOME/rtlc/bin/behavc-vle
fi
export BEHAVC=$TBX_HOME/rtlc/bin/behavc-vle

export INCR_CLEAN=TRUE
export LIB_FILE=$BEHAVC_HOME/lib/bhv_med_sim.v
export DIFF_CMD="diff -w -B"
export PATH=$TBXREGINFRA/scripts/OS3:$TBXREGINFRA/scripts:${PATH}

if [[ -z $VELOCE_PLATFORM ]] ; then
    if [[ ! -z $Emulator ]]  ; then
        export VELOCE_PLATFORM=`grep $Emulator $TBXREGINFRA/scripts/Emulator.list | awk '{print $7}'`
        if  [[ $VELOCE_PLATFORM == "" ]] ; then
            unset VELOCE_PLATFORM
            echo "Did not get info for $Emulator in $TBXREGINFRA/scripts/Emulator.list . Unable to set VELOCE_PLATFORM" >> /dev/stderr
        fi
    fi
fi
