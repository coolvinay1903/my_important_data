#!/bin/bash -f
if [[ -z $MED_TBX_HOME ]]; then
    export MED_TBX_HOME=/in/inntbx9/tbx/vps/sandbox/os3fp/v1800/tbx
fi
if [[ -z $VMW_HOME ]]; then
    export VMW_HOME=/in/inntbx9/tbx/vps/sandbox/os3fp/v1800
fi
export LD_LIBRARY_PATH=/in/grid/sge/lib/lx-amd64:$MED_TBX_HOME/rtlc/rtlcLib:/med/build/gcc/gcc-6.2.0/rhel6/lib64:/usr/lib:/usr/local/lib
export MW_HOME=$MED_TBX_HOME
export TBX_EMUL_PLATFORM=D2
export TERM=xterm
export BUILD_PLATFORM=linux_el30_gnu53
export DIAMOND=1
export NO_VEL_ON_VLE=1
export TIME_CONTROL=1
export BEHAVC_REG_HOME=/home/tbxreg/regressions/TBX_REGRESSIONS
export VELOCE_HOME=$VMW_HOME
export TBXREGINFRA=/home/tbxreg/GIT_REGRESSION_SCRIPTS/tbxreg
export VPS_REGRESSIONS=TRUE
export VPS_REGRESSIONS_USE_TAPI=TRUE
export PRECISE_UTIL=/in/inntbx9/tbx/vps/sandbox/builds/tbx_1800/src/rtlc/Applications/Decryptor/PreciseDecrypt
export MMI_RUN_DIR=/in/inntbx9/tbx/vps/sandbox/builds/tbx_1800/src/src/mct/red_sw_hw_link/source/mmi_run_dir
source /home/vinays/bash_settings/vps_runtime_env.sh
source /home/vinays/bash_settings/env_script.sh
export TBX_COMMON_CONFIG_OPTS=/home/tbxreg/GIT_REGRESSION_SCRIPTS/tbxreg/scripts/OS3/vps_common_config_opts
export INCR_CLEAN=TRUE
export TBX_REGRESSIONS=TRUE
source /home/vinays/bash_settings/vxl8.1.sh
source /home/vinays/bash_settings/que10.4b.sh
export BEHAVC_EXEC=$MED_TBX_HOME/rtlc/bin/behavc-vle
export BEHAVC_HOME=$MED_TBX_HOME/rtlc
export BEHAVC=$MED_TBX_HOME/rtlc/bin/behavc-vle
export BEHAVC_COMMON_OPT="-hdl verilog -write_cdfg -allow_4ST -preserve -process_sign -compile_hier_tf -allow_bhv_sysvlog"
export VERILOG=my_mti
export BRANCH=tbx_1800
export RTLC_HOME=$MED_TBX_HOME/rtlc
export MIXED_RTLC_HOME=$MED_TBX_HOME/rtlc
export HOME_0IN=/in/zero-in-v10.3d_4/linux/linux_x86_64
export TERM=xterm
export DUMP_AREA=$PWD
echo  "Please set DUMP_AREA correctly. It is currently set to '$DUMP_AREA'."

