#!/bin/bash -f
function buildKernel() {

    #Start within kernel
    /in/scmtools/Linux3/bin/pbox $BUILD_PLATFORM
    if  [[ ! -z $1 ]] && [[ $1 == "clean"  ]] ; then
        make clean
    fi
    make | tee ~/public/junk/kernelBuildLogs/$BUILD_PLATFORM.kernel.log 2>&1
    if  [[ $? -ne 0 ]] ; then
        xmessage -center "KERNEL BUILD FAILED in mct" &
        echo FAILED for $BUILD_PLATFORM
        return -1;
    fi

    cd ../exportlibs
    #/in/scmtools/Linux3/bin/pbox exportlibs
    /in/scmtools/Linux3/bin/pbox $BUILD_PLATFORM
    if  [[ ! -z $1 ]] && [[ $1 == "clean"  ]] ; then
        make clean
    fi
    make | tee ~/public/junk/kernelBuildLogs/$BUILD_PLATFORM.exportlib.log 2&>1
    if  [[ $? -ne 0 ]] ; then
        grep -e "TioStream::operator<<" ~/public/junk/kernelBuildLogs/$BUILD_PLATFORM.exportlib.log
        if  [[ $? -ne 0 ]] ; then
            xmessage -center "KERNEL BUILD FAILED in mctExportlibs" &
            echo FAILED for $BUILD_PLATFORM
            cd ../kernel
            return -1;
        fi
    fi

    cd ../../modelworks/middleware
    /in/scmtools/Linux3/bin/pbox $BUILD_PLATFORM
    if  [[ ! -z $1 ]] && [[ $1 == "clean"  ]] ; then
        make clean
    fi
    make | tee ~/public/junk/kernelBuildLogs/$BUILD_PLATFORM.middleware.log 2>&1
    if  [[ $? -ne 0 ]] ; then
        xmessage -center "KERNEL BUILD FAILED in middleware" &
        echo FAILED for $BUILD_PLATFORM
        cd ../../mct/kernel
        return -1;
    fi

    cd .. ;
    make update
    if  [[ $? -ne 0 ]] ; then
        xmessage -center "KERNEL BUILD FAILED in modelworks" &
        echo FAILED for $BUILD_PLATFORM
        cd ../mct/kernel
        return -1;
    fi

    xmessage -center "KERNEL BUILD PASSED for $BUILD_PLATFORM. \n CREATE BEHAVC LINKS IF NEEDED" &

    cd ../mct/kernel/
    echo "Kernel BUILD PASSED"
    return 0;
}
function buildKernelAll() {
    clean="";
    if  [[ ! -z $1 ]]  && [[ $1 == "clean" ]]; then
        clean="clean";
    fi
    for platform in `\ls ../../common/lib/|grep gnu4`; do
        export BUILD_PLATFORM=$platform
        xmessage -center "Compiling for platform $BUILD_PLATFORM" &
        buildKernel $clean
        if  [[ $? -ne 0 ]] ; then
            xmessage -center "KERNEL BUILD FAILED FOR $BUILD_PLATFORM" &
        fi
    done
    exit 0;
}
#buildKernelAll "$@"
