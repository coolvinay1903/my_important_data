#!/bin/bash

# extract version..
grep " 1.0." $MW_HOME/etc/mct_version.dat >& /dev/null
if [[  $status == 0  ]]; then
    export BRANCH=tbx_100
    export PATH=$MW_HOME/bin/sparcv8:${PATH}
    if  [[ $Platform == "linux" ]] ; then
        echo "Linux platform not supported TBX 1.0"
        exit -1
    fi
else
    grep " 3\.0\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_300 ##karunas
    fi

    grep " 3\.0\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_301 ##karunas
    fi

    grep "3\.0\.2" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_310 ##karunas
    fi

    grep " 3\.1\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_310 ##karunas
    fi

    grep " 3\.16" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_310 ##karunas
    fi

    grep " 3\.16\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_3161
    fi

    grep " 3\.16\.3" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_3163
    fi

    grep " 17\.0\." $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1703
    fi

    grep " 17\.0\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1700
    fi

    grep " 17\.0\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1701
    fi


    grep " 17\.1\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1710
    fi

    grep " 18\.0\." $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1800
    fi

    grep " 18\.1\." $MW_HOME/etc/mct_version.dat >& /dev/null
    if  [[ $status == 0  ]] ; then
        export BRANCH=tbx_1810
    fi

fi

# Older branches
if [[ -z $BRANCH ]] ; then
    grep " 1.2." $MW_HOME/etc/mct_version.dat >& /dev/null
    if [[  $status == 0  ]]; then
        export BRANCH=tbx_120
    else
        #DPK :
        # done for 1.3 release .
        grep " 1.3." $MW_HOME/etc/mct_version.dat >& /dev/null
        if [[  $status == 0  ]]; then
            export BRANCH=tbx_120
        else
            grep " 2\.0\." $MW_HOME/etc/mct_version.dat >& /dev/null
            if [[  $status == 0 ]]; then
                export BRANCH=tbx_200
            else
                grep " 2\.1\." $MW_HOME/etc/mct_version.dat >& /dev/null
                if [[ $status == 0 ]]; then
                    export BRANCH=tbx_210
                    export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_210/OCPTBX
                else
                    grep " 2\.2\.2\." $MW_HOME/etc/mct_version.dat >& /dev/null
                    if [[ $status == 0  ]]; then
                        export BRANCH=tbx_222
                        export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                        # Setting following env var. common.config will contain
                        # no_auto_clk_bind so as to enable cview mode compilation
                        # ManishS
                        # export TBX_COMMON_CONFIG_OPTS=$ROOT_TBX/common.config
                    else
                        grep " 2\.2\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
                        if [[ $status == 0  ]]; then
                            export BRANCH=tbx_221
                            export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                            # Setting following env var. common.config will contain
                            # no_auto_clk_bind so as to enable cview mode compilation
                            # ManishS
                            # export TBX_COMMON_CONFIG_OPTS=$ROOT_TBX/common.config
                        else
                            grep " 2\.2\." $MW_HOME/etc/mct_version.dat >& /dev/null
                            if [[ $status == 0  ]]; then
                                export BRANCH=tbx_220
                                export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                                # Setting following env var. common.config will contain
                                # no_auto_clk_bind so as to enable cview mode compilation
                                # ManishS
                                #setenv TBX_COMMON_CONFIG_OPTS $ROOT_TBX/common.config
                            else
                                grep " 2\.3\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
                                if [[ $status == 0  ]]; then
                                    export BRANCH=tbx_230
                                fi

                                grep " 2\.3\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
                                if [[ $status == 0  ]]; then
                                    export BRANCH=tbx_231
                                    if [[ ! -z $KERNEL_64BIT ]] ;then
                                        export MTI_VCO_MODE=64
                                    fi
                                    export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                                    # Setting following env var. common.config will contain
                                    # no_auto_clk_bind so as to enable cview mode compilation
                                    # ManishS
                                    #setenv TBX_COMMON_CONFIG_OPTS $ROOT_TBX/common.config
                                else
                                    grep " 2\.4\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
                                    if [[ $status == 0  ]]; then
                                        export BRANCH=tbx_240
                                        grep " 2\.4\.0\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_241
                                        else
                                            grep " 2\.4\.0\-" $MW_HOME/etc/mct_version.dat >& /dev/null
                                            if  [[ $status == 0  ]] ; then
                                                export BRANCH=tbx_241
                                            fi
                                        fi
                                        grep " 2\.4\.0\.16" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_242
                                        fi

                                        if [[ ! -z $KERNEL_64BIT ]] ;then
                                            export MTI_VCO_MODE=64
                                        fi
                                        export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                                        # Setting following env var. common.config will contain
                                        # no_auto_clk_bind so as to enable cview mode compilation
                                        # ManishS
                                        #setenv TBX_COMMON_CONFIG_OPTS $ROOT_TBX/common.config
                                    else
                                        grep " 2\.4\.1" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_242
                                        fi

                                        grep " 2\.4\.1\.1.dev" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_243
                                        fi

                                        grep " 2\.4\.1\.MayRelease" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_242_may
                                        fi

                                        grep " 2\.4\.2" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_242_may
                                            echo "1.Setting branch $BRANCH"
                                        fi

                                        grep " 2\.4\.3" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_243
                                        fi

                                        grep " 2\.4\.4" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_244
                                        fi

                                        grep " 2\.4\.5" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_245
                                        fi

                                        grep " 2\.5\.0" $MW_HOME/etc/mct_version.dat >& /dev/null
                                        if  [[ $status == 0  ]] ; then
                                            export BRANCH=tbx_250
                                            if [[ ! -z $VELCOMP_REGRESSION ]] || [[ ! -z $TBX_OS3LEGACY_FLOW ]] ;then
                                                export BRANCH=tbx_300
                                            fi
                                        fi

                                        if [[ ! -z $KERNEL_64BIT ]] ;then
                                            export MTI_VCO_MODE=64
                                        fi
                                        export OCP_HOME=$ROOT_TBX/tbx_regressions/product/tbx_dev/OCPTBX
                                        # Setting following env var. common.config will contain
                                        # no_auto_clk_bind so as to enable cview mode compilation
                                        # ManishS
                                        # export TBX_COMMON_CONFIG_OPTS=$ROOT_TBX/common.config
                                    fi
                                fi
                            fi
                        fi
                    fi
                fi
            fi
        fi
    fi
fi

if [[ -z $BRANCH ]] ; then
    # Default
    export BRANCH=tbx_1701
fi
