#!/usr/bin/perl -w
use Switch;
#This is pass 2 to convert some global contructs which are difficult to
#handle based on simple token parsing
sub pass_two {
    my $row = shift;
    my $replace_str=$row;
    # if  [[ ! $?VELOCE_PLATFORM ]] ; then
    # if  [[ ! ${?VELOCE_PLATFORM} ]] ; then
    # if  [[ $?Emulator ]]  ; then
    # if  [[ ${?Emulator} ]]  ; then
    # if  [[ $?Emulator == 0 ]]  ; then
    # if  [[ ${?Emulator} == 0 ]]  ; then
    if ( $row =~/(.*)if\s*[\(\[]+\s*(\!)?\s*\$(\{)?\?(\w+)(\})?\s*((\=\=|\!\=)\s*(0|1))?\s*[\)\]]+(.*)/ ) {
        $replace_str = "";
        #print "row = $row";
        my $str="";
        my $first = "";
        if ( defined $2 && $2 eq "!") {
            $str = "==0";
        }
        $first = $4;
        #print "Found if -z construct\n";
        if ( defined $6 && $6 ne "") {
            $str="$7$8";
        }
        if ( $str eq "") {
            $str = "!=0";
        }
        #print "first = $first\n";
        #print "str = $str\n";
        #####  == 0 =>   -z
        #####  == 1 => ! -z
        #####  != 0 => ! -z
        #####  != 1 =>   -z
        my $last = "";
        if (defined $9 && $9 ne "") {
            $last = $9;
            if ($last =~/then/ ) {
                if ( $last =~/;/) {
                    ;
                }
                else {
                    $last =~s/then/;then/;
                }
            }
        }
        switch($str) {
            case "==0" { $replace_str = "${1}if [[ -z \$$first ]]$last"}
            case "==1" { $replace_str = "${1}if [[ ! -z \$$first ]]$last"}
            case "!=0" { $replace_str = "${1}if [[ ! -z \$$first ]]$last"}
            case "!=1" { $replace_str = "${1}if [[ -z \$$first ]]$last"}
        }
        print "1. $replace_str\n";
    }
    # set path = ( $TBXREGINFRA/scripts/OS3 $TBXREGINFRA/scripts $path )
    elsif ( $row =~/set\s+path\s*\=\s*(.*)/) {
        my $str = $1;
        chomp($str);
        $str=~s/[\(\)]//g;
        $str=~s/^\s+//;
        $str=~s/\s+$//;
        $str=~s/\s+/:/g;
        $str=~s/\$path/\$\{PATH\}/g;
        $replace_str = "export PATH=$str";
        print "2. $replace_str\n";
    }
    #  if($BRANCH == tbx_3161 || $BRANCH == tbx_1703) then
    elsif ( $row=~/if\s*\((.*)\)\s*then/ ) {
        $replace_str = "if [[ $1 ]]; then";
        print  "3. $replace_str\n";
    }
    #    if ($setBhvc) setenv BEHAVC_REG_HOME /home/medqa/SANDBOXES/TBX_REGRESSIONS
    elsif ( $row=~/if\s*[\(\[]+(.*)[\)\]]+\s*(\S+.*)/ ) {
        my $stat = $2;
        if ( $stat=~/then/) {
            ;
        } else {
            my $str = $1;
            $str=~s/[\)\]]+$//g;
            $replace_str = "if [[ $str ]]; then $stat; fi";
            print  "4. $replace_str\n";
        }
    }
    # set A = B
    elsif ( $row=~/set\s+(\S+)\s*\=\s*(.*)/) {
        $replace_str = "$1=$2";
        print  "5. $replace_str\n";
    }
    #unsetenv -> unset
    $replace_str=~s/unsetenv/unset/g;
    #else if -> elif
    $replace_str=~s/else\s+if/elif/g;
    #$path -> ${PATH}
    $replace_str=~s/\$path/\$\{PATH\}/g;
    return $replace_str;
}

my $filename = $ARGV[0];
my $ofilename = "$filename.sh";
print "file = $filename\n";
print "Out file = $ofilename\n";
open(my $fh, '<', $filename) or die "Could not open file '$filename' $!";
open(my $ofh, '>', $ofilename) or die "Could not open file '$ofilename' $!";
my $from_alias=0;
while (my $row = <$fh>) {
    chomp $row;
    my @split_args = split (' ', $row);
    my $rep_str = "";
    my $inside_if=0;
    my $inside_if_cond=0;
    for (my $i =0; $i <= $#split_args; $i++) {
        #print "arg = $split_args[$i]\n";
        my $curr_arg = $split_args[$i];
        #print "current_arg = $curr_arg\n";
        if ( $curr_arg eq "#!/bin/csh" || $curr_arg eq "#!/usr/bin/csh" ) {
            $curr_arg = "#!/bin/bash";
            $rep_str="${rep_str} $curr_arg";
        } elsif ( $curr_arg eq "if" ) {
            $inside_if++;;
            $rep_str="${rep_str} $curr_arg";
        } elsif ( $curr_arg eq "endif" ) {
            $inside_if--;
            $rep_str="${rep_str} fi";
        } elsif ( $curr_arg eq "endsw" ) {
            $rep_str="${rep_str} esac";
       } elsif ( $inside_if && $curr_arg =~/\(/ ) {
            $inside_if_cond = 1;
            $curr_arg=~s/\(/ \[[ / ;
            $curr_arg=~s/\)/ \]] / ;
            $rep_str="${rep_str} $curr_arg";
        } elsif  ( $inside_if && $inside_if_cond && $curr_arg =~/\)/ ) {
            $curr_arg=~s/\)/ \]]/;
            $rep_str="${rep_str} $curr_arg";
        } elsif ( $inside_if && $inside_if_cond && $curr_arg eq "then" ) {
            $inside_if_cond = 0;
            $curr_arg="; then";
            $rep_str="${rep_str} $curr_arg";
        } elsif ( $curr_arg eq "alias" ) {
            if ( $i+1 <= $#split_args) {
                $rep_str = "$rep_str alias $split_args[($i+1)]=";
                $i++;
                $from_alias=1;
            } else {
                $rep_str = "$rep_str $curr_arg";
            }
        } elsif ( $curr_arg eq "'setenv" ) {
            $rep_str = "${rep_str}'export $split_args[($i+1)]=$split_args[($i+2)]";
            $i = $i+2;
        } elsif  ( $curr_arg eq "setenv" ) {
            $rep_str = "$rep_str export $split_args[($i+1)]=$split_args[($i+2)]";
            $i = $i+2;
        } else {
            if ($from_alias) {
                $rep_str="${rep_str}$curr_arg";
                $from_alias=0;
            } else {
                $rep_str="${rep_str} $curr_arg";
            }
        }
    }
    $rep_str = pass_two($rep_str);
    print $ofh "$rep_str\n";
}
close($fh);
close($ofh);
