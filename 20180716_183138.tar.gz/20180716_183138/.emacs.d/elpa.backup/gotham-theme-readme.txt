A port of the Gotham theme for Vim to Emacs 24 that uses the new
theming support.
