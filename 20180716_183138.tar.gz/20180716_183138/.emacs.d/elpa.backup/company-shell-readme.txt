Backend for company mode to complete environment variables, binaries found
on your $PATH and fish shell functions.
